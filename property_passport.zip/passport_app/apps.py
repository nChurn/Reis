from django.apps import AppConfig


class PassportAppConfig(AppConfig):
    name = 'passport_app'
