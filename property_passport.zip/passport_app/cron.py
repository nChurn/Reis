from .tasks import tasks
def my_scheduled_job():
    print("hello")
    tasks()
    pass